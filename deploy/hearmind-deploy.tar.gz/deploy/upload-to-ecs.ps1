# HearMind - Upload from Windows to Alibaba Cloud ECS and deploy via Docker
# Usage (from project root in PowerShell):
#   .\deploy\upload-to-ecs.ps1
#
# Requires SSH access: root@120.55.181.0 (key or password)

param(
    [string]$EcsIp = "120.55.181.0",
    [string]$SshUser = "root",
    [string]$RemoteDir = "/opt/hearmind"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root

Write-Host ">>> Deploy HearMind to ${SshUser}@${EcsIp}" -ForegroundColor Cyan

$envFile = Join-Path $Root ".env.deploy"
$dashKey = ""
$keyPath = Join-Path $Root "config\dashscope.key"
if (Test-Path $keyPath) {
    foreach ($line in Get-Content $keyPath) {
        $t = $line.Trim()
        if ($t -and -not $t.StartsWith("#") -and $t.StartsWith("sk-")) {
            $dashKey = $t
            break
        }
    }
}
if (-not $dashKey) {
    Write-Host "WARN: no sk- key in config/dashscope.key" -ForegroundColor Yellow
}

$mysqlPass = "Hm_" + [guid]::NewGuid().ToString("N").Substring(0, 16)
$jwtSecret = "hearmind-jwt-" + [guid]::NewGuid().ToString("N") + [guid]::NewGuid().ToString("N")

$envContent = @"
MYSQL_ROOT_PASSWORD=$mysqlPass
DASHSCOPE_API_KEY=$dashKey
AUTH_JWT_SECRET=$jwtSecret
HTTP_PORT=80
"@
[System.IO.File]::WriteAllText($envFile, $envContent, [System.Text.UTF8Encoding]::new($false))

Write-Host ">>> Generated .env.deploy (MySQL password saved locally)"

$archive = Join-Path $env:TEMP "hearmind-deploy.tar.gz"
if (Test-Path $archive) { Remove-Item $archive -Force }

Write-Host ">>> Packing project (excluding storage/target/node_modules)..."
tar -czf $archive `
    --exclude=.git `
    --exclude=backend/target `
    --exclude=./backend/storage `
    --exclude=frontend/node_modules `
    --exclude=frontend/dist `
    --exclude=config/cookies.txt `
    --exclude=.env `
    --exclude=.env.deploy `
    -C $Root .

$sizeMb = [math]::Round((Get-Item $archive).Length / 1MB, 1)
Write-Host ">>> Archive ${sizeMb} MB"

$remote = "${SshUser}@${EcsIp}"
Write-Host ">>> Testing SSH..."
ssh -o ConnectTimeout=15 -o BatchMode=yes $remote "echo ok && mkdir -p $RemoteDir/config"
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "ERROR: SSH failed (Permission denied). Fix one of:" -ForegroundColor Red
    Write-Host "  1. Add your SSH public key in Alibaba Cloud console -> ECS -> Key Pair" -ForegroundColor Yellow
    Write-Host "  2. Or run this script in PowerShell where you can enter root password" -ForegroundColor Yellow
    Write-Host "  3. Or manual deploy: see deploy/ECS_MANUAL_STEPS.md" -ForegroundColor Yellow
    Write-Host "  Archive ready: $archive" -ForegroundColor Yellow
    exit 1
}

Write-Host ">>> Uploading..."
scp -o ConnectTimeout=60 $archive "${remote}:/tmp/hearmind-deploy.tar.gz"
scp -o ConnectTimeout=30 $envFile "${remote}:${RemoteDir}/.env"
if (Test-Path "config\dashscope.key") {
    scp -o ConnectTimeout=30 "config\dashscope.key" "${remote}:${RemoteDir}/config/dashscope.key"
}
if (Test-Path "config\bilibili.cookies.txt") {
    scp -o ConnectTimeout=30 "config\bilibili.cookies.txt" "${remote}:${RemoteDir}/config/bilibili.cookies.txt"
}

Write-Host ">>> Remote build and start (first run 5-15 min)..."
$remoteCmd = "set -e; mkdir -p $RemoteDir; tar -xzf /tmp/hearmind-deploy.tar.gz -C $RemoteDir; chmod +x $RemoteDir/deploy/*.sh 2>/dev/null || true; bash $RemoteDir/deploy/remote-setup.sh $RemoteDir"
ssh $remote $remoteCmd

Write-Host ""
Write-Host "==========================================" -ForegroundColor Green
Write-Host "  Open: http://${EcsIp}" -ForegroundColor Green
Write-Host "  Credentials: $envFile" -ForegroundColor Green
Write-Host "  Logs: ssh $remote 'cd $RemoteDir && docker compose logs -f backend'" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green
